/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseproject;

import com.mysql.jdbc.Connection;
import java.io.IOException;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author Burcu
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class ConnectController implements Initializable {

   static Connection connection;
    
    @FXML
    private Button connect;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void connectButton(ActionEvent event) throws SQLException, ClassNotFoundException {
        // Load the JDBC driver
        Class.forName("com.mysql.jdbc.Driver");
        System.out.println("Driver loaded");

        // Connect to a database
        connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/javaschema", "root", "");
        System.out.println("Database connected");
        
        
        try {
            Stage stage2 = (Stage) connect.getScene().getWindow();
            stage2.close();

            Stage stage = new Stage();

            Parent root = FXMLLoader.load(getClass().getResource("Table.fxml"));
            Scene scene = new Scene(root);

            stage.setScene(scene);
            stage.setTitle("DB BROWSER");
            stage.setMinHeight(500);
            stage.setMinWidth(500);

            stage.show();
        } catch (IOException ex) {
            //Logger.getLogger(FXML2Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static Connection getConnection() {
        return connection;
    }
    
}
