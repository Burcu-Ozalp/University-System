/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseproject;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Burcu
 */
public class TableController implements Initializable {

    @FXML
    private ListView<String> listOfTables;
    @FXML
    private Button display;
    @FXML
    private Button query;

    /**
     * Initializes the controller class.
     */
    Statement statement;
    DatabaseMetaData dbMetaData;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            try {
                statement = ConnectController.getConnection().createStatement();
                
            } catch (SQLException ex) {
                Logger.getLogger(CustomQueryController.class.getName()).log(Level.SEVERE, null, ex);
            }

            try {
                dbMetaData = ConnectController.getConnection().getMetaData();
                
            } catch (SQLException ex) {
                Logger.getLogger(CustomQueryController.class.getName()).log(Level.SEVERE, null, ex);
            }

            String[] types = {"TABLE"};
            ResultSet rs = dbMetaData.getTables(null, null, "%", types);
            while (rs.next()) {
                listOfTables.getItems().add(rs.getString("TABLE_NAME"));
                //System.out.println(rs.getString("TABLE_NAME"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CustomQueryController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void displayButton(ActionEvent event) throws SQLException, IOException {
        Stage stage2 = (Stage) display.getScene().getWindow();
        stage2.close();
            
        Stage stage = new Stage();

        Parent root = FXMLLoader.load(getClass().getResource("DisplayContents.fxml"));
        Scene scene = new Scene(root);

        stage.setScene(scene);
        stage.setTitle("DB BROWSER");
        stage.setMinHeight(500);
        stage.setMinWidth(500);

        stage.show();
        /*statement.executeUpdate("create table Course(\n" +
"  courseID char(5),\n" +
"  subjectID char(4) not null, \n" +
"  courseNum integer,\n" +
"  title varchar(50) not null,\n" +
"  numCredit integer,\n" +
"  primary key (courseID) )");*/
    }

    @FXML
    private void queryButton(ActionEvent event) {
        try {
            Stage stage2 = (Stage) query.getScene().getWindow();
            stage2.close();

            Stage stage = new Stage();

            Parent root = FXMLLoader.load(getClass().getResource("ResultOfCustomQuery.fxml"));
            Scene scene = new Scene(root);

            stage.setScene(scene);
            stage.setTitle("DB BROWSER");
            stage.setMinHeight(500);
            stage.setMinWidth(500);

            stage.show();
        } catch (IOException ex) {
            //Logger.getLogger(FXML2Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
