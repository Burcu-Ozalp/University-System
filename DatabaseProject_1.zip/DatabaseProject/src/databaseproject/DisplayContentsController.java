/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseproject;

import java.io.IOException;
import java.net.URL;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Burcu
 */
public class DisplayContentsController implements Initializable {

    @FXML
    private ListView<String> listOfTables;
    @FXML
    private TableView<?> wholeTable;
    @FXML
    private Button addButton;
    @FXML
    private Button updateSelected;
    @FXML
    private Button deleteSelected;
    @FXML
    private Button displayContent;
    @FXML
    private Button customQuery;

    /**
     * Initializes the controller class.
     */
    Statement statement;
    DatabaseMetaData dbMetaData;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
        try {
                    statement = ConnectController.getConnection().createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE, //The result set is scrollable and sensitive to changes in the database
                    ResultSet.CONCUR_UPDATABLE);
        } catch (SQLException ex) {
            Logger.getLogger(DisplayContentsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
                dbMetaData = ConnectController.getConnection().getMetaData();
                
            } catch (SQLException ex) {
                Logger.getLogger(CustomQueryController.class.getName()).log(Level.SEVERE, null, ex);
            }

            String[] types = {"TABLE"};
            ResultSet rs = dbMetaData.getTables(null, null, "%", types);
            while (rs.next()) {
                listOfTables.getItems().add(rs.getString("TABLE_NAME"));
                //System.out.println(rs.getString("TABLE_NAME"));
            }
        }catch (SQLException ex) {
            Logger.getLogger(CustomQueryController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }    

    @FXML
    private void addButtonAction(ActionEvent event) throws SQLException {
        Stage stage2 = (Stage) addButton.getScene().getWindow();
        stage2.close();
        
        String query = "select state, capital from StateCapital";
        ResultSet resultSet = statement.executeQuery(query);
        resultSet.last();
        resultSet.moveToInsertRow(); // Move cursor to the insert row
        resultSet.updateString("state", "Florida");
        resultSet.updateString("capital", "Tallahassee");
        resultSet.insertRow(); // Insert the row
        resultSet.moveToCurrentRow(); // Move the cursor to the current row 
    }

    @FXML
    private void updateSelectedAction(ActionEvent event) throws SQLException {
        Stage stage2 = (Stage) updateSelected.getScene().getWindow();
        stage2.close();
        
        String query = "select state, capital from StateCapital";
        ResultSet resultSet = statement.executeQuery(query);
        resultSet.absolute(2); // Move cursor to the second row    
        resultSet.updateString("state", "New State"); // Update the column
        resultSet.updateString("capital", "New Capital"); // Update the column
        resultSet.updateRow(); // Update the row in the data source
    }

    @FXML
    private void deleteSelectedAction(ActionEvent event) throws SQLException {
       Stage stage2 = (Stage) deleteSelected.getScene().getWindow();
        stage2.close();
        
        String query = "select state, capital from StateCapital";
        ResultSet resultSet = statement.executeQuery(query);
        resultSet.absolute(4); // Move cursor to the 4th row
        resultSet.deleteRow(); // Delete the 4th row
    }

    @FXML
    private void displayContentAction(ActionEvent event) {
        
    }

    @FXML
    private void customQueryAction(ActionEvent event) {
        try {
            Stage stage2 = (Stage) customQuery.getScene().getWindow();
            stage2.close();

            Stage stage = new Stage();

            Parent root = FXMLLoader.load(getClass().getResource("CustomQuery.fxml"));
            Scene scene = new Scene(root);

            stage.setScene(scene);
            stage.setTitle("DB BROWSER");
            stage.setMinHeight(500);
            stage.setMinWidth(500);

            stage.show();
        } catch (IOException ex) {
            //Logger.getLogger(FXML2Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
