/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databaseproject;

import java.io.IOException;
import java.net.URL;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Burcu
 */
public class ResultOfCustomQueryController implements Initializable {

    
    @FXML
    private TextArea Result;
    @FXML
    private TextField queryField;
    @FXML
    private Button execute;
    @FXML
    private Button display;
    @FXML
    private Button query;
    @FXML
    private ListView<String> listOfTables;

    Statement statement;
    DatabaseMetaData dbMetaData;
ResultSet resultSet;
ResultSetMetaData rsmd;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {

            try {
                statement = ConnectController.getConnection().createStatement();
            } catch (SQLException ex) {
                Logger.getLogger(CustomQueryController.class.getName()).log(Level.SEVERE, null, ex);
            }

            try {
                dbMetaData = ConnectController.getConnection().getMetaData();

            } catch (SQLException ex) {
                Logger.getLogger(CustomQueryController.class.getName()).log(Level.SEVERE, null, ex);
            }

            String[] types = {"TABLE"};
            ResultSet rs = dbMetaData.getTables(null, null, "%", types);
            while (rs.next()) {
                listOfTables.getItems().add(rs.getString("TABLE_NAME"));
                //System.out.println(rs.getString("TABLE_NAME"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(CustomQueryController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void queryField(ActionEvent event) {
    }

    @FXML
    private void executeButton(ActionEvent event) throws SQLException {
        // Execute a statement
        //ResultSet resultSet = statement.executeQuery(queryField.getText());
        //System.out.println("results"+resultSet.toString());

        // Execute a statement
        resultSet = statement.executeQuery(queryField.getText());
        // Iterate through the result and print the student names
        //Retrieving the ResultSetMetaData object
        rsmd = resultSet.getMetaData();
        //getting the column type
        int column_count = rsmd.getColumnCount();
        System.out.println("Number of columns in the table : " + column_count);
        int i = 1;
        while (column_count >= i) {
            System.out.println(rsmd.getColumnName(i));
            Result.appendText(rsmd.getColumnName(i)+"\n");
            
            while (resultSet.next()) {
                System.out.println(resultSet.getString(i));
                Result.appendText(resultSet.getString(i)+"\n");
               
            }
        resultSet = statement.executeQuery(queryField.getText());
        rsmd = resultSet.getMetaData();
            i++; 
        }
    }

    @FXML
    private void displayButton(ActionEvent event) throws IOException {
        Stage stage2 = (Stage) display.getScene().getWindow();
        stage2.close();

        Stage stage = new Stage();

        Parent root = FXMLLoader.load(getClass().getResource("DisplayContents.fxml"));
        Scene scene = new Scene(root);

        stage.setScene(scene);
        stage.setTitle("DB BROWSER");
        stage.setMinHeight(500);
        stage.setMinWidth(500);

        stage.show();
    }

    @FXML
    private void customQuery(ActionEvent event) {
        Stage stage2 = (Stage) query.getScene().getWindow();
        stage2.close();

    }

}

    

